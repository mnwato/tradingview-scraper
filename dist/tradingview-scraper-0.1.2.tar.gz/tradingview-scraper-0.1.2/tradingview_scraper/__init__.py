# Inside of __init__.py

from tradingview_scraper.tradingview_scraper import ClassA